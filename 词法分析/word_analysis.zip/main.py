import preprocess
import process

if __name__=='__main__':
    preprocess.preprocess('file.txt')
    process.process('preprocess.txt')