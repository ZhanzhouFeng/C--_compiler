import preprocess1
import process

if __name__=='__main__':
    preprocess1.preprocess('file.txt')
    process.process('preprocess.txt')